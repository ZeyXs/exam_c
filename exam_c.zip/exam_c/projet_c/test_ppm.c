// test_ppm.c : Lit une image en couleur (ppm binaire P6)
//				Ecrit cette image dans un nouveau fichier
//
#include <stdio.h>
#include <stdlib.h>
#include "pnm.h"

int main(int argc, char* argv[])
{
    FILE *inFileDesc, *outFileDesc;
    imgdesc iDesc;
    OCTET *raster;
    if (argc != 3) {
        fprintf(stderr,"Usage: ImageIn.ppm ImageOut.ppm\n");
        exit(EXIT_FAILURE);
    }
    inFileDesc = fopen(argv[1],"r");
    if(inFileDesc==NULL) {
        fprintf(stderr,"Impossible de lire %s\n",argv[1]);
        exit(EXIT_FAILURE);
    }
    outFileDesc = fopen(argv[2],"r");
    if(outFileDesc!=NULL) {
        fprintf(stderr,"Copie impossible : %s existe\n",argv[2]);
        fclose(inFileDesc);
        exit(EXIT_FAILURE);
    }
    outFileDesc = fopen(argv[2],"w");
    if(outFileDesc==NULL) {
        fprintf(stderr,"Impossible de creer %s\n",argv[2]);
        fclose(inFileDesc);
        exit(EXIT_FAILURE);
    }
    iDesc = read_header(inFileDesc);
    if(iDesc.type != PPMb) {
        fprintf(stderr,"Format P%d non pris en charge\n",iDesc.type);
        fclose(inFileDesc);
        fclose(outFileDesc);
        exit(EXIT_FAILURE);
    }
    raster = malloc_raster(iDesc);
    if(raster==NULL) {
        fprintf(stderr,"Allocation memoire impossible\n");
        fclose(inFileDesc);
        fclose(outFileDesc);
        exit(EXIT_FAILURE);
    }
    read_raster(inFileDesc,iDesc,raster);
    write_img(outFileDesc,iDesc,raster);
    free(raster);
    fclose(inFileDesc);
    fclose(outFileDesc);
    exit(EXIT_SUCCESS);
}
