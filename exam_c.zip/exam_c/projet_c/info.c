#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "pnm.c"


int main(int argc, char *argv[]) {
	assert (argc == 2);
	
	char *nom_fichier = argv[1];
	FILE *fd = fopen(nom_fichier, "r");
	
	imgdesc a = read_header(fd);
	
	printf("%d, %d, %d, %d, %d, %ld", a.type, a.width, a.height, a.depth, a.depthSize, a.start);
	return 0;
}