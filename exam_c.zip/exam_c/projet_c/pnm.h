#ifndef PNM_h
#define PNM_h

#include <stdio.h>

#define PBMa 1  // noir et blanc ASCII
#define PGMa 2  // niveau de gris ASCII
#define PPMa 3  // RVB ASCII
#define PBMb 4  // noir et blanc binaire
#define PGMb 5  // niveau de gris binaire
#define PPMb 6  // RVB binaire

typedef struct image_descriptor {
    char type; //PBMa, ... , PPMb
    int width, height, depth;
    int depthSize;   // number of bytes to represent a value of depth (1 if depth > 256 or 2 else)
    long start; // offset for the raster
} imgdesc;

typedef unsigned char OCTET;

/**
 \brief Read the header of a PNM file
 \param pf, a PNM file descriptor
 \return an image descriptor for the image in pf
*/
imgdesc read_header(FILE * pf);

/**
 \brief Allocate a memory zone to store a raster
 \param desc, an image descriptor
 \return the adress of a memory zone for a raster described by desc or NULL
*/
OCTET *malloc_raster(imgdesc desc);

/**
 \brief Read the raster of an image from a PNM file
 \param pf, a PNM file descriptor
 \param desc, its image descriptor
 \param buf, a sufficiently large memory zone
 \return store the raster of the image in pf described by desc in the zone pointed by buf
*/
void read_raster(FILE *pf, imgdesc desc, OCTET *buf);

/**
 \brief write a header and a raster in a PNM file
 \param pf, a PNM file descriptor
 \param desc, its image descriptor
 \param buf, the pixels of the image
 \return overwrite the file pf with an image described by desc whom the pixels are in buf
*/
void write_img(FILE *pf, imgdesc desc, OCTET *buf);

#endif /* PNM_h */

