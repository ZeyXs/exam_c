#include <stdio.h>
#include <stdlib.h>
#include "pnm.h"



int main(int argc, char * argv[]) {
    // Verification du nombre d'arguments
    if(argc!=4) {
        fprintf(stderr,"%s seuil fic_source fic_dest\n",argv[0]);
        exit(EXIT_FAILURE);
    }
    
    // Recuperation du seuil (une valeur entre 0 et 255)
    int seuil = atoi(argv[1]);
    if(seuil<0 || seuil>255) {
        fprintf(stderr,"seuil %s incorrect\n",argv[1]);
           exit(EXIT_FAILURE);
       }
    // Ouverture du fichier source
    FILE *fd_source = fopen(argv[2], "r");
    if(fd_source == NULL) {fprintf(stderr, "Le fichier source n'a pas pu être ouvert."); exit(EXIT_FAILURE);}
    
    // Ouverture du fichier destination
    FILE *fd_destination = fopen(argv[3], "w");
    if(fd_destination == NULL) {fprintf(stderr, "Le fichier destination n'a pas pu être ouvert."); exit(EXIT_FAILURE);}
    
    // Lecture de l'entete dans une structure imgdesc
    imgdesc a = read_header(fd_source);
    
    // Reservation d'une zone memoire pour charger les pixels
    // Un pixel fait 1 octet selon les conditions données
    // Un octet est un unsigned char
    OCTET *buffer = malloc(a.width * a.height * 3);    

    // Lecture des pixels
    // On doit lui passer les paramètres du header
    read_raster(fd_source, a, buffer);

    // Seuillage :
    for(int y=0; y<a.height; y++) {
        for(int x=0; x<a.width*3; x+=3) {
            *(buffer + x + y*a.width*3 + 0) = *(buffer + x + y*a.width*3 + 0) < seuil ? 0 : 255;
            *(buffer + x + y*a.width*3 + 1) = *(buffer + x + y*a.width*3 + 1) < seuil ? 0 : 255;
            *(buffer + x + y*a.width*3 + 2) = *(buffer + x + y*a.width*3 + 2) < seuil ? 0 : 255;
        }
    }

    // Ecriture de l'image dans fichier de sortie
    write_img(fd_destination, a, buffer);
    
    // Liberation de la memoire
    free(buffer);

    // Fermeture des fichiers
    //*** A COMPLETER
    fclose(fd_source);
    fclose(fd_destination);

    exit(EXIT_SUCCESS);
}