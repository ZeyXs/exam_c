#include <stdlib.h>
#include "pnm.h"
#include <assert.h>

// Seul le format PGMb est pris en compte
// Il vous faudra etendre ces fonctions pour les autres formats PNM
// Pour simplifier, les cas d'erreurs sont sauvagement sanctionnes d'un exit


/*
 Each PGM image consists of the following:
     - A "magic number" for identifying the file type. A pgm image's magic number is the two characters "P5".
     - Whitespace (blanks, TABs, CRs, LFs).
     - A width, formatted as ASCII characters in decimal.
     - Whitespace.
     - A height, again in ASCII decimal.
     - Whitespace.
     - The maximum gray value (Maxval), again in ASCII decimal. Must be less than 65536, and more than zero.
     - A single whitespace character (usually a newline).
     - A raster of Height rows, in order from top to bottom. Each row consists of Width gray values, in order from left to right. Each gray value is a number from 0 through Maxval, with 0 being black and Maxval being white. Each gray value is represented in pure binary by either 1 or 2 bytes. If the Maxval is less than 256, it is 1 byte. Otherwise, it is 2 bytes. The most significant byte is first.
*/


void ignore_comment(FILE *pf) {
    char c;
    do {
        c = getc(pf);
    } while (c!=EOF && c!='\n');
}

char read_type(FILE *pf) {
    int type = 0;
    int items;
    do {
        switch(fgetc(pf)) {
            case ' ':
            case '\t':
            case '\n' :
            case '\r':
                break;
            case '#' :
                ignore_comment(pf);
                break;
            case 'P' :
                items = fscanf(pf, "%d", &type);
                if(items == 0 || type<1 || type>6) {
                    fprintf(stderr,"Erreur de format (type %d inconnu)\n",type);
                    exit(EXIT_FAILURE);
                }
                break;
            case EOF :
            default :
                fprintf(stderr,"Erreur de format (type %d inconnu)\n",type);
                exit(EXIT_FAILURE);
        }
    } while(type == 0);
    return type;
}

int read_val(FILE *pf) {
    int val = 0;
    _Bool valLue = 0;
    char c;
    do {
        c = fgetc(pf);
        switch(c) {
            case ' ':
            case '\t':
            case '\n' :
            case '\r':
                break;
            case '#' :
                ignore_comment(pf);
                break;
            case '1' : case '2' : case '3' : case '4' : case '5' :
            case '6': case '7' : case '8' : case '9' :
                if(ungetc(c,pf)==EOF) {
                    fprintf(stderr,"Erreur buffer\n");
                    exit(EXIT_FAILURE);
                }
                valLue = fscanf(pf,"%d",&val);
                if(valLue == 0) {
                    fprintf(stderr,"Erreur de format (valeur entiere non reconnue)\n");
                    exit(EXIT_FAILURE);
                }
                break;
            case EOF :
            default :
                fprintf(stderr,"Erreur de format (valeur entiere non reconnue)\n");
                exit(EXIT_FAILURE);
        }
    } while(valLue == 0);
    return val;
}

imgdesc read_header (FILE *pf) {
    //creation d'un descripteur initialise a 0
    imgdesc desc = {};
    // on se remet au debut du fichier
    fseek(pf, 0, SEEK_SET);
    // lecture du type
    desc.type = read_type(pf);
    // lecture de la largeur
    desc.width = read_val(pf);
    //lecture de la hauteur
    desc.height = read_val(pf);
    //si PGM ou PPM lecture de maxVal
    if(desc.type != PBMa && desc.type != PBMb) {
        desc.depth = read_val(pf);
        if(desc.depth>=0 && desc.depth < 256 ) desc.depthSize = 1;
        else if(desc.depth>=256 && desc.depth < 65536 ) desc.depthSize = 2;
        else {
            fprintf(stderr,"Erreur de format (la profondeur %d n'est pas dans les bornes)\n",desc.depth);
            exit(EXIT_FAILURE);
        }
    }
    else {
        desc.depth =  1;
        desc.depthSize = 1;
    }
    // on doit alors lire un unique espace blanc
    char ws = fgetc(pf);
    if(ws!=' ' && ws!='\t' && ws!='\n' && ws!='\r') {
        fprintf(stderr,"Erreur de format (%c n'est pas un caractere espace valide)\n",ws);
        exit(EXIT_FAILURE);
    }
    // on note l'octet de depart de la trame
    desc.start = ftell(pf);
    return desc;
}

OCTET *malloc_raster(imgdesc desc) {
    if(desc.type == PGMa || desc.type == PGMb) {
        // cas PGM
        return (OCTET *)malloc(desc.height * desc.width * desc.depthSize);
    }
    else if(desc.type == PPMa || desc.type == PPMb) {
        // cas PPM
        // AJOUT
        return (OCTET *)malloc(desc.height * desc.width * desc.depthSize * 3);
    }
    else {
        //cas PBM
        // AJOUT
        return (OCTET *)malloc(desc.height * desc.width * desc.depthSize);
    }
}

void read_raster(FILE *pf, imgdesc desc, OCTET *buf) {
    // positionnement au debut de l'image (apres l'entete)
    fseek(pf, desc.start, SEEK_SET);
    // lecture des pixels
    // cas PGMb
    if(desc.type==PGMb){
        if(fread(buf, desc.depthSize * desc.height * desc.width, 1, pf)  !=  1) {
            fprintf(stderr,"Erreur de lecture\n");
            exit(EXIT_FAILURE);
        }
    }
    // cas PPMb
    // AJOUT
    else if(desc.type==PPMb) {
        if(fread(buf, desc.depthSize * desc.height * desc.width * 3, 1, pf)  !=  1) {
            fprintf(stderr,"Erreur de lecture\n");
            exit(EXIT_FAILURE);
        }
    }
    // cas ASCII ou PBM
    // AJOUT
    else {
        if(fread(buf, desc.depthSize * desc.height * desc.width, 1, pf)  !=  1) {
            fprintf(stderr,"Erreur de lecture\n");
            exit(EXIT_FAILURE);
        }
    }
}

void write_img(FILE *pf, imgdesc desc, OCTET *buf) {
    // positionnement au debut du fichier
    fseek(pf,0,SEEK_SET);
    // ecriture de l'entete
    // cas PGMb
    if(desc.type == PGMb) {
        fprintf(pf,"P%d\n%d %d\n%d\n", desc.type, desc.width, desc.height, desc.depth);
        fwrite(buf, desc.depthSize * desc.height * desc.width, 1, pf);
    }
    // cas PPMb
    else if(desc.type==PPMb) {
        fprintf(pf,"P%d\n%d %d\n%d\n", desc.type, desc.width, desc.height, desc.depth);
        fwrite(buf, desc.depthSize * desc.height * desc.width * 3, 1, pf);
    }
    // cas PBM ou ASCII
    else {
        fprintf(pf,"P%d\n%d %d\n%d\n", desc.type, desc.width, desc.height, desc.depth);
        fwrite(buf, desc.depthSize * desc.height * desc.width, 1, pf);
    }
}

