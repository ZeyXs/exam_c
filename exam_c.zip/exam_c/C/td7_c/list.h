#ifndef LIST_H
#define LIST_H

struct cell {
    int head;
    struct cell *tail;
};

typedef struct cell *list;

list cons(list li, int element);
void edit(list li, int element, int index);
void concatenate(list *l1, list *l2);
list duplicate(list li);
list remove_head(list li);
int len(list li);
int get(list li, int index);
void show(list li);

#endif