#include <stdio.h>
#include <stdlib.h>
#include "list.h"

list cons(list li, int element) {
    list new_li = (list) malloc(sizeof(struct cell));
    if (new_li == NULL) {
        printf("Error: Can not append new value. Out of memory.\n");
        exit(1);
    }
    new_li->head = element;
    new_li->tail = li;
    return new_li;
}

void edit(list li, int element, int index) {
    int i;
    for (i = 0; i < index && li != NULL; i++) li = li->tail;
    if (i == index && li != NULL) li->head = element;
    else printf("Index out of bounds");
}

list remove_head(list li) {
    if (li == NULL) return NULL;
    list tail = li->tail;
    free(li);
    return tail;
}

int len(list li) {
    int n = 0;
    while (li != NULL) {
        n++;
        li = li->tail;
    }
    return n;
}

int get(list li, int index) {
    int i = 1;
    while (i < index && li != NULL) {
        i++;
        li = li->tail;
    }
    if (index < 1 || li == NULL) {
        printf("Error: Index out of bounds.");
        exit(1);
    }
    return li->head;
}

list duplicate(list li) {
    list copy = NULL, prec = NULL;
    if (li == NULL) return NULL;
    copy = (list) malloc(sizeof(struct cell));
    prec = copy;
    prec->head = li->head;
    while(li->tail != NULL) {
        list cel = (list) malloc(sizeof(struct cell));
        li = li->tail;
        cel->head = li->head;
        prec->tail = cel;
        prec = cel;
    }

}

void concatenate(list *l1, list *l2) {
    if (*l1 == NULL) *l1 = *l2;
    else concatenate(&((*l1)->tail), l2);
}

/*
l1 = [1, 2, 3, 4] l2 = [5, 6, 7]
concatenate(&l1, &l2)

[1]
[1, 2]
[1, 2, 3]
[1, 2, 3, 4]
[1, 2, 3, 4, NULL] -> [1, 2, 3, 4, 5, 6, 7]

*/

void show(list li) {
    printf("[");
    if (li != NULL) { printf("%d,", li->head); li = li->tail; }
    while (li != NULL) {
        if (li->tail == NULL) printf("%d", li->head);
        else printf("%d,", li->head);
        li = li->tail;
    }
    printf("]\n");
}
