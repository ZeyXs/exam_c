#include <stdio.h>

typedef struct date {
    int day, month, year;
} date;

typedef struct sommet {
    char *name;
    date date;
    struct sommet * voisins[];
} sommet;

typedef struct graphe {
    sommet s;
    struct sgraphe * voisin;
} graphe;

typedef struct cellule {
    sommet g;
    struct cellule * suiv;
} cellule;

typedef cellule * graphe;

void afficher(graphe g) {
    while (g != NULL) {
        printf("Sommet %s %d/%d/%d :\n", g->val.name, g->val.date.day, g->val.date.month, g->val.date.year);$
        for (int i=0; i<g->val.voisins; i++) {
            printf("\t ami de %s\n", g->val.voisins[i]->val.name);
        }
    }
}

int main() {
    return 0;
}