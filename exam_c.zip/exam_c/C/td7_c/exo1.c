#include <stdio.h>
#include "list.h"

// list li = NULL;
// li = inserer()

int main() {
    list l1 = NULL, l2 = NULL;

    l1 = cons(cons(cons(cons(l1, 4), 3), 2), 1);
    l2 = cons(cons(cons(l2, 7), 6), 5);
    
    concatenate(&l1, &l2);

    show(l1);

    return 0;
}