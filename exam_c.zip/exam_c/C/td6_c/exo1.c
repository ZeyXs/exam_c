#include <stdio.h>
#include <stdlib.h>

#define TAILLE 5

int* lireTableau(int n);
void afficherTableau(int* tab, int n);

int main() {

    int* tab = lireTableau(TAILLE);
    afficherTableau(tab, TAILLE);

    free(tab);

    return 0;
}

int* lireTableau(int n) {
    int* tab = (int*) malloc(n * sizeof(int));
    
    printf("Entrez %d entiers pour construire un tableau :\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &tab[i]);
    }

    return tab;
}

void afficherTableau(int* tab, int n) {
    printf("Affichage du tableau :\n");
    for (int i=0; i<n; i++) {
        printf("%d ", tab[i]);
    }
    printf("\n");
}