#include <stdio.h>
#include <stdlib.h>

// => 140 octets
//    *(td+(2*5)+1) <=> td[2*5+1]
//    free(td); / td = NULL;

// => 140 octets dans le tas et 8 cotets dans la pile
//    *(td+(2*5)+1) <=> td[2*5+1]
//    free(td); / td = NULL;

// => 8 octets dans la pile, 7*8 = 56 octets dans le tas, 7 zones de 5*4 = 20 octets = 140 octets
//    td[2][1]
//    for (int i=0; i<7; i++) { free(td[i]); td[i] = NULL; }
//    free(td); / td = NULL;

// => 8 octets
// => 20 octets

int main() {

    int td[7][5] = {
        {1,2,3,4,5},
        {1,2,3,4,5},
        {1,2,3,4,5},
        {1,2,3,4,5},
        {1,2,3,4,5},
        {1,2,3,4,5},
        {1,2,3,4,5}
    };

    printf("%d\n", *(*(td+2)+1));

    return 0;
}