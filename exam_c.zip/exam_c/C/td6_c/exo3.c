#include <stdio.h>
#include <stdlib.h>

#define TAILLE 5

int* extraitPairs(int* tab);

void afficherTableau(int* tab, int n) {
    printf("Affichage du tableau :\n");
    for (int i=0; i<n; i++) {
        printf("%d ", tab[i]);
    }
    printf("\n");
}

int* lireTableau(int n) {
    int* tab = (int*) malloc(n * sizeof(int));
    
    printf("Entrez %d entiers pour construire un tableau :\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &tab[i]);
    }

    return tab;
}

int main() {
    int* listPairs = lireTableau(TAILLE);
    int* pairs = extraitPairs(listPairs);
    free(listPairs);
    free(pairs);
    return 0;
}

int* extraitPairs(int* td) {
    int tailleTr = 0, j = 0;
    for (int i=0; i<TAILLE; i++) if (td[i] % 2 == 0) tailleTr++;
    int* tr = (int*) malloc(tailleTr * sizeof(int));
    for (int i=0; i<TAILLE; i++) {
        if (td[i] % 2 == 0) {
            tr[j] = td[i];
            j++;
        }
    }
    afficherTableau(tr, tailleTr);
    return tr;
}