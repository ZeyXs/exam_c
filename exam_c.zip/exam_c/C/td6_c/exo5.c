#include <stdio.h>
#include <stdlib.h>

#define TAILLE 5

int* realloc_tab(int* tab, int old_size, int new_size);

int main() {
    int* tab = (int*) malloc(TAILLE * sizeof(int));
    for (int i = 0; i < TAILLE; i++) {
        tab[i] = i;
    }
    tab = realloc_tab(tab, 5, 10);
    for (int i = 0; i < 10; i++) {
        printf("%d ", tab[i]);
    }
    printf("\n");
    free(tab);
    return 0;
}

int* realloc_tab(int* tab, int old_size, int new_size) {
	int* new_tab = (int*) malloc(new_size * sizeof(int));
	for (int i = 0; i < old_size; i++) {
		new_tab[i] = tab[i];
	}
	return new_tab;
}