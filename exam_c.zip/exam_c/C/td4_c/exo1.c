#include <stdio.h>
#include <stdbool.h>

bool saisieValIntervalle(int *n, int a, int b);

int main() {
    int n;
    bool inInterval;
    do {
        inInterval = saisieValIntervalle(&n, 0, 10);
    } while (!inInterval);
    printf("%d est dans l'intervalle\n", n);

    return 0;
}

bool saisieValIntervalle(int *n, int a, int b) {
    scanf("%d", n);
    if (*n >= a && *n <= b) {
        return true;
    }
    return false;
}