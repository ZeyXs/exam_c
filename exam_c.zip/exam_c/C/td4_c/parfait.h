bool isPerfect(int n);
void calcPerfectIn(int a, int b);
int getPerfect(int n);
bool isPerfectIn(int *n, int d);
