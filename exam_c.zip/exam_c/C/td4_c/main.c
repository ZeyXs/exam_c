#include <stdio.h>

struct temps {
	int hours;
	int minutes;
	float seconds;
};

int main(struct temps temps) {
    // utilisation des fonctions disponible dans "parfait.h"
    return 0;
}

