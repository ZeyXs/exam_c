#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void handle_notes(FILE *fp, const char* path) {

    float sum = .0f;

    int student_id, res_scanf, amount = 0;
    char firstname[51], name[51], abi[4];
    float note;

    do {
        res_scanf = fscanf(fp, "%d%50s%50s%f", &student_id, firstname, name, &note);

        switch (res_scanf) {
            case EOF: break;
            case 4:
                amount++;
                sum += note;
                break;
            case 3:
                if (fscanf(fp, "%3s", abi) && (strcmp(abi, "ABI") == 0)) {
                    //fprintf()
                    //Ecriture dans le second fichier
                }
                break;
            default:
                fclose(fp); // fclose(fp2)
                fprintf(stderr, "Format incorrect\n");
                exit(EXIT_FAILURE);
        }

    } while (res_scanf != EOF);

    printf("Moyenne : %f", sum/(float)amount);
}

int main(int argc, char **argv) {

    if (argc != 2) {
        printf("Usage: %s file_path\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *fp = fopen(argv[1], "r");

    if (fp == NULL) {
        printf("Error: File can't be opened.\n");
        return EXIT_FAILURE;
    }

    handle_notes(fp, realpath(argv[1], NULL));

    if (fclose(fp) == EOF) {
        printf("Error: File can't be closed\n");
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}