#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>

#define USAGE "Usage: ./calc [operand] {sqr|sqrt|+|-|*|/} <operand>\n"

int main(int argc, char *argv[]) {

    if (argc < 2) {
        printf(USAGE);
        return EXIT_FAILURE;
    }

    if (argc == 3) {

        if ((strcmp(argv[1], "sqr") == 0)) printf("%f\n", atof(argv[2]) * atof(argv[2]));
        else if ((strcmp(argv[1], "sqrt")) == 0) printf("%f\n", sqrt(atof(argv[2])));
        else { printf(USAGE); return EXIT_FAILURE; }

    } else if (argc == 4) {

        if ((strcmp(argv[2], "+")) == 0) {
           printf("%f\n", atof(argv[1])+atof(argv[3]));
        } else if ((strcmp(argv[2], "-")) == 0) {
           printf("%f\n", atof(argv[1])-atof(argv[3]));
        } else if ((strcmp(argv[2], "*")) == 0) {
           printf("%f\n", atof(argv[1])*atof(argv[3]));
        } else if ((strcmp(argv[2], "/")) == 0) {
           printf("%f\n", atof(argv[1])/atof(argv[3]));
        } else {
           printf(USAGE);
           printf("coui\n");
           return EXIT_FAILURE;
        }

    } else {
        printf(USAGE);
        return EXIT_FAILURE;
    }
}