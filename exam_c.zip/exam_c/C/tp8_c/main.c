#include <stdio.h>

struct data_meteo {
    float temp_min, temp_max;
    int pluviometry;
    char description[256];
};

int addMeteo(FILE *fp, struct data_meteo data);

int main() {

}

int addMeteo()