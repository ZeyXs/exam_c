/*  secondprog.c 
    Compiler avec : 
    gcc -Wall secondprog.c -o secondprog
*/

#include <stdio.h>

int main()
{
  int a,b;
  a=5;
  b=8;

  printf("Félicitation ! Vous avez réussi à corriger un programme en C \n");

  return 0;
}
