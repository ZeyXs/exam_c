#include <stdio.h>

int main()
{
    int x = (1+2)*5+8/3-47;
    printf("%d\n", x);
    return 0;
}