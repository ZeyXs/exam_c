#include <stdio.h>

int main()
{
    int f;
    printf("Choisir une température en Fahrenheit : ");
    scanf("%d", &f);
    int celsius = (f-32)*5/9;
    printf("%d\n", celsius);
    return 0;
}