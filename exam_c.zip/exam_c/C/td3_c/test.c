#include <stdio.h>
#include <stdbool.h>

int main() {
    bool x = false;
    printf("%s\n", x ? "true" : "false");
    return 0;
}