#include <stdio.h>
#include <stdbool.h>

int plusGrandDiv(int i, int b) {
    return (b % i) == 0 ? i : plusGrandDiv(i-1, b);
}

bool premierRec(int n) {
    return plusGrandDiv(n-1, n) == 1; 
}

int main() {
    printf("%d\n", plusGrandDiv(5, 15));
    printf("%d\n", premierRec(567));
    return 0;
}