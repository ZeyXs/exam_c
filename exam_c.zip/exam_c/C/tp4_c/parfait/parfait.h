#ifndef PARFAIT_H
#define PARFAIT_H
#include <stdbool.h>

bool isPerfect(int n);
int findPerfect(int a, int b);
int getPerfect(int n);
bool existsPerfect(int n, int d);

#endif