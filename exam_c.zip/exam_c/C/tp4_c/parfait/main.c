#include <stdio.h>
#include "parfait.h"

void testeParfait();

int main() {
    testeParfait();
    return 0;
}

void testeParfait() {
    int input, n, d;
    printf("[0] Quitter   [1] isPerfect   [2] findPerfect   [3] getPerfect   [4] existsPerfect\n");
    do {
        printf("Votre choix : ");
        scanf("%d", &input);
    } while (input < 0 && input > 4);
    switch (input) {
        case 0:
            break;
        case 1:
            prinf("Saisissez un entier n : ");
            scanf("%d", &n);
            printf("%s\n", isPerfect(n) ? "true" : "false");
            break;
        case 2:
            scanf("%d%d", &n, &d);
            findPerfect(n, d);
            break;
        case 3:
            scanf("%d", &n);
            printf("%d\n", getPerfect(n));
            break;
        case 4:
            scanf("%d%d", &n, &d);
            existsPerfect(n, d);
        default:
            printf("Erreur de saisie :(\n");
            break;
    }
}