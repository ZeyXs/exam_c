#include "parfait.h"

int sumDiv(int n) {
    int sum = 0;
    for (int i = 1; i<=n; i++) {
        if (n % i == 0) {
            sum += i;
        }
    }
    return sum;
}

bool isPerfect(int n) {
    return sumDiv(n) == (n*2);
}

int findPerfect(int a, int b) {
    int res;
    for (int i = a; a<=b; i++) {
        if (isPerfect(i)) {
            res = i;
        }
    }
    return res;
}

int getPerfect(int n) {
    int i = 1;
    while (n > 0) {
        if (isPerfect(i)) {
            n--;
        }
        i++;
    }
    return i;
}

bool existsPerfect(int n, int d) {
    for (int i = (n-d); i<(n+d); i++) {
        if (isPerfect(i)) {
            return 1;
        }
    }
}

