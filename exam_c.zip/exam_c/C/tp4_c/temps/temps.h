#ifndef TEMPS_H
#define TEMPS_H

struct temps {
    int hour;
    int minute;
    float second;
};

struct intervalle {
    struct temps minimum;
    struct temps maximum;
};

void showTime(struct temps time);
int convertToSeconds(struct temps time);
struct temps convertFromSeconds(int seconds);
struct temps addTime(struct temps time, struct temps timeToAdd);
struct intervalle calcArrivalTime(struct temps departureTime, struct temps duration, float coef);

#endif