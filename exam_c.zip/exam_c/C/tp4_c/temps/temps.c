#include <stdio.h>
#include "temps.h"

void showTime(struct temps temps) {
    printf("%02d:%02d:%02f\n", temps.hour, temps.minute, temps.second);
}

int convertToSeconds(struct temps temps) {
    int second;
	while (temps.hour > 0) {
		second += 3600;
		temps.hour--;
	}
	while (temps.minute > 0) {
		second += 60;
		temps.minute--;
	}
	second += temps.second;
	return second;
}

struct temps convertFromSeconds(int seconds) {
    int hour = seconds / 3600;
    seconds -= (hour * 3600);
    int minute = seconds/60;
    seconds -= (minute * 60);
    struct temps temps = {hour, minute, seconds};
    return temps;
}

struct temps addTime(struct temps time, struct temps timeToAdd) {
    struct temps sum_time;
    sum_time.second = convertFromSeconds(convertToSeconds(time) + timeToAdd.second).second;
    sum_time.minute = (int) (time.minute + timeToAdd.minute + (time.second + timeToAdd.second) / 60) % 60;
    sum_time.hour = (int) (time.hour + timeToAdd.hour + (time.minute + timeToAdd.minute + (time.second + timeToAdd.second) / 60) / 60);
    return sum_time;
}

struct intervalle calcArrivalTime(struct temps departureTime, struct temps duration, float coef) {
    struct temps minArrivalTime = addTime(departureTime, duration);
    struct temps maxDuration = {0, 0, ((duration.hour * coef) * 3600 + (duration.minute * coef )* 60 + (duration.second * coef))};
    struct temps maxArrivalTime = addTime(departureTime, maxDuration);

    struct intervalle res = {minArrivalTime, maxArrivalTime};
    return res;
}