#include <stdio.h>
#include "temps.h"

int main() {
    struct temps depart = {12, 30, 0};
    struct temps duration = {1, 0, 0};
    float coef = 2.5;
    
    struct intervalle interval = calcArrivalTime(depart, duration, coef);
    printf("Minimum : ");
    showTime(interval.minimum);
    printf("Maximum : ");
    showTime(interval.maximum);

    /*
    struct temps time = {12, 9, 43.245};
    showTime(time);
    */

    return 0;
}