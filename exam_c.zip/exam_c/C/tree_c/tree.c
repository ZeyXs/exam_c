#include <stdio.h>
#include <stdlib.h>

struct node
{
    int key;
    struct node *left;
    struct node *right;
};

struct node* create(int value);
struct node* insertLeft(struct node* root, int value);
struct node* insertRight(struct node* root, int value);
void parcoursInfixe(struct node* root);

int main()
{
    struct node* root = create(1);
    insertLeft(root, 4);
    insertRight(root, 6);
    insertLeft(root->left, 42);
    insertRight(root->left, 3);
    insertLeft(root->right, 2);
    insertRight(root->right, 33);

    parcoursInfixe(root);

    return 0;
}

struct node* create(int value)
{
    struct node* newNode = malloc(sizeof(struct node));
    newNode->key = value;
    newNode->left = NULL;
    newNode->right = NULL;

    return newNode;
}

struct node* insertLeft(struct node* root, int value)
{
    root->left = create(value);
    return root->left;
}

struct node* insertRight(struct node* root, int value)
{
    root->right = create(value);
    return root->right;
}

void parcoursInfixe(struct node* root) {
  if (root == NULL) return;
  parcoursInfixe(root->left);
  parcoursInfixe(root->right);
  printf("%d\n", root->key);
}
