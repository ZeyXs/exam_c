#include <stdio.h>
#include <stdlib.h>
#include "utils.h"

int* lireTableau(int n) {
    int* tab = (int*) malloc(n * sizeof(int));
    
    printf("Entrez %d entiers pour construire un tableau :\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &tab[i]);
    }

    return tab;
}

void afficherTableau(int* tab, int n) {
    printf("Affichage du tableau :\n");
    for (int i=0; i<n; i++) {
        printf("%d ", tab[i]);
    }
    printf("\n");
}