#ifndef PAIR_H
#define PAIR_H

int* lireTableau(int n);
void afficherTableau(int* tab, int n);

#endif