#include <stdio.h>
#include <stdlib.h>
#include "utils.h"

#define TAILLE 25

void changeTaille(int** tab, int current_size, int new_size);

int main() {
    int* tab = (int*) malloc(TAILLE * sizeof(int));
    for (int i = 0; i < TAILLE; i++) tab[i] = i+1;
    afficherTableau(tab, TAILLE);

    changeTaille(&tab, TAILLE, 10);
    afficherTableau(tab, 10);

    changeTaille(&tab, 10, 30);
    afficherTableau(tab, 30);

    free(tab);
    return 0;
}

void changeTaille(int **tab, int current_size, int new_size) {
    int* new_tab = (int*) malloc(new_size * sizeof(int));
    for (int i=0; i<new_size; i++) if (i < current_size) new_tab[i] = *tab[i];
    *tab = new_tab;
}