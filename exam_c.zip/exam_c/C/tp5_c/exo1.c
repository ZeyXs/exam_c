#include <stdio.h>
#include <stdlib.h>
#include "utils.h"

int* extraitPairs(int* tab, int n);

int main() {
    int n;
    printf("Renseigner la taille du tableau : ");
    scanf("%d", &n);

    int* listPairs = lireTableau(n);
    int* pairs = extraitPairs(listPairs, n);

    free(listPairs);
    free(pairs);
    return 0;
}

int* extraitPairs(int* td, int n) {
    int tailleTr = 0, j = 0;
    for (int i=0; i<n; i++) if (td[i] % 2 == 0) tailleTr++;
    int* tr = (int*) malloc(tailleTr * sizeof(int));
    for (int i=0; i<n; i++) {
        if (td[i] % 2 == 0) {
            tr[j] = td[i];
            j++;
        }
    }
    afficherTableau(tr, tailleTr);
    return tr;
}