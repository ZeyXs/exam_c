#include <stdio.h>
#include <stdlib.h>

int* init_array(int (*tab)[5], int lignes, int colonnes) {
    for(int i=0; i<lignes; i++) {
        for(int j=0; j<colonnes; j++) {
            (*tab)[i*colonnes+j] = 0;
        }
    }
}

void static_array() {
    int td[7][5];
    init_array(td, 7, 5);
    td[0][0] = 42; td[1][1] = 42; td[2][2] = 42; td[5][5] = 42; td[6][0] = 42;

    for (int i = 0; i < sizeof(td)/sizeof(td[0]); i++) {
        for (int j = 0; j < sizeof(td[0])/sizeof(int); j++) printf("%d ", td[i][j]);
        printf("\n");
    }
}

void alice() {
    int *td = (int*) malloc(7*5*sizeof(int));
    td[0] = 42; td[1*5+1] = 42; td[2*5+2] = 42; td[5*5+5] = 42; td[6*5+0] = 42;
    for (int i = 0; i < 7; i++) {
        for (int j = 0; j < 5; j++) {
            printf("%d ", td[i+j]);
        }
        printf("\n");
    }

    free(td);
}

void camille_dominique() {
    int **td = (int **)malloc(7*sizeof(int*));
    for(int i = 0; i < 7; i++) td[i] = (int*) malloc(5*sizeof(int));

    td[0][0] = 42; td[1][1] = 42; td[2][2] = 42; td[5][5] = 42; td[6][0] = 42;

    for (int i = 0; i < 7; i++) {
        for (int j = 0; j < 5; j++) {
            printf("%d ", td[i][j]);
        }
        printf("\n");
    }

    for(int i=0; i<7; i++) free(td[i]);
    free(td); 
}

int main() {
    camille_dominique();
    return 0;
}