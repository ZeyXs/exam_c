#include <stdio.h>
#include <stdbool.h>
#include <math.h>

int unite(int n);
int dizaine(int n);
int centaine(int n);
bool testeProp(int n);
void testeTous();
void testeTriplet(int c, int d, int u);
void testeToutTriplet();

int main() {
    printf("%d\n", testeProp(371));
    testeTous();
    return 0;
}

int unite(int n) {
    return n%10;
}

int dizaine(int n) {
    return (n%100)/10;
}

int centaine(int n) {
    return (n%1000)/100;
}

bool testeProp(int n) {
    return (pow(unite(n), 3) + pow(dizaine(n), 3) + pow(centaine(n), 3)) == n;
}

void testeTous() {
    for (int i = 2; i <= 999; i++) {
        if (testeProp(i)) {
            printf("%d\n", i);
        }
    }
}

void testeTriplet(int c, int d, int u) {
    return testeProp(c+(d*10)+(u*100));
}

void testeToutTriplet() {
    for (int i = 1; i <= 9; i++) {
        for (int j = 1; j <= 9; j++) {
            for (int k = 1; k <= 9; k++) {
                testeTriplet(i, j, k);
            }
        }
    }
}

