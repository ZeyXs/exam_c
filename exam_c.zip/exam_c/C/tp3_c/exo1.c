#include <stdio.h>
#include <stdbool.h>

int saisieNote();
float moyenne(int n);

int main() {
    printf("%f\n", moyenne(2));
    return 0;
}

int saisieNote() {
    int note;
    printf("Veuillez saisir une note entre 0 et 20 : ");
    int input = scanf("%d", &note);
    return (note >= 0 && note <= 20 && input != 0) ? note : -1;
}

float moyenne(int n) {
    int i = 0;
    int sum = 0;
    while (i < n) {
        int note;
        do {
            if (note == -1) printf("Votre saisie est incorrect.\n");
            note = saisieNote();
        } while (note == -1);
        sum += note;
        i++;
    }
    return (float)sum/(float)i;
}