#include <stdio.h>

_Bool estPremier(int n);

int main()
{
    estPremier(120);
    return 0;
}

_Bool estPremier(int n)
{
    int div;
    for(int i=2; i<n; i++)
    {
        if (n%i == 0)
        {
            break;
        }
    }
    return ;
}