#include <stdio.h>

int main()
{
    int in[3];
    scanf("%d%d%d", &in[0], &in[1], &in[2]);

    int max = in[0];
    int min = in[0];
    int len = sizeof(in)/sizeof(in[0]);

    for (int i=0; i<len; i++)
    {
        if (in[i] > max)
        {
            max = in[i];
        }
        if (in[i] < min)
        {
            min = in[i];
        }
    }

    printf("max: %d\nmin: %d\n", max, min);
    return 0;
}