#include <stdio.h>

int power(int x, int y);

int main()
{
    printf("%d\n", power(0,0));
    return 0;
}

int power(int x, int n)
{
    int res = 1;
    for (int i=0; i<n; i++)
    {
        res *= x;
    }
    return res;
}