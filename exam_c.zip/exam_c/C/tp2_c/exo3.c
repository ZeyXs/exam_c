#include <stdio.h>

double reel(int n);

int main()
{
    printf("%f\n", reel(999999999));
    return 0;
}

double reel(int n)
{
    double res = 0.;
    for (int i=1; i<=n; i++)
    {
        res += 1./(double) i;
    }
    return res;
}