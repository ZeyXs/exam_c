#include <stdio.h>

int main()
{
    int n = 0, som = 0, in;
    do
    {
        scanf("%d", &in);
        if (in > 0) 
        {
            n++;
            som += in;
        }
    } while (in > 0);
    
    printf("%f\n", (float)som/n);
    return 0;
}