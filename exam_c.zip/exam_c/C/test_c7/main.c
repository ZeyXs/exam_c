#include <stdio.h>
#include <math.h>

double test(double a);

int main()
{
    test(5.);
    return 0;
}

double test(double a)
{
    if (a < 0.)
    {
        return 1.;
    } else
    {
        printf("%f\n", sqrt(a));
        return test(a-1.);
    }
}